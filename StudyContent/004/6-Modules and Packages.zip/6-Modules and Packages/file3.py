import sys
import file1
num = int(sys.argv[1])
print(file1.myfunc(num))